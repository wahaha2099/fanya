
package com.example.th3;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.fiberhome.arksdkdemo.R;
import com.fiberhome.mobileark.sso.MobileArkSSOAgent;
import com.fiberhome.mobileark.sso.SSOConnectStatusListener;

public class SSOActivity extends Activity
{
	private Button bt;
//	private Button bt2;
	private Button bt3;
	private Button bt4;
	private Button bt5;
	private TextView tv;

	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);

		setContentView(R.layout.activity_third3);
		bt = (Button) findViewById(R.id.button1);
//		bt2 = (Button) findViewById(R.id.button2);
		bt3 = (Button) findViewById(R.id.button3);
		bt4 = (Button) findViewById(R.id.button4);
		bt5 = (Button) findViewById(R.id.button5);
		tv = (TextView) findViewById(R.id.text1);
		bt.setOnClickListener(new OnClickListener()
		{
			@Override
			public void onClick(View v)
			{
				bt.setEnabled(false);
				tv.setText("单点登录  数据发送中，请不要关闭页面耐心等待。。。");
				
				MobileArkSSOAgent.getInstance().startConnectSSO(
						SSOActivity.this.getApplicationContext(), new SSOConnectStatusListener()
						{
							@Override
							public void finishCallBack()
							{
								bt.setEnabled(true);
								String message = "";
								message = " code=" + getStatus() + "\n message=" + getMessage();
								if (getStatus())
								{
									HashMap<String,String> params = getParams();
									Iterator iter = params.entrySet().iterator();
									while(iter.hasNext()){
										Map.Entry entry = (Map.Entry)iter.next();
										message += "\n "+entry.getKey()+"=" + entry.getValue();
									}
									
								}
								tv.setText(message);
								Log.i("thirdapptest", message);
								return;
							}
						});
			}
		});
		
	
		bt3.setOnClickListener(new OnClickListener()
		{
			@Override
			public void onClick(View v)
			{
				tv.setText("数据发送中，请不要关闭页面耐心等待。。。");
				
			}
		});
		
		bt4.setOnClickListener(new OnClickListener()
		{
			@Override
			public void onClick(View v)
			{
				tv.setText("数据发送中，请不要关闭页面耐心等待。。。");
				
			}
		});
		
		bt5.setOnClickListener(new OnClickListener()
		{
			@Override
			public void onClick(View arg0)
			{
				
			}
		});
	}


	@Override
	protected void onDestroy()
	{
		super.onDestroy();
		MobileArkSSOAgent.getInstance().onDestroy();
		return;
	}

	class ClientVersionUpdataAsyncTask extends AsyncTask<Integer, Integer, String>
	{
		@Override
		protected String doInBackground(Integer... arg0)
		{
			for (int i = 0; i < 5000; i++)
			{

			}
			return arg0[0] == 0 ? "" : "1";
		}

		@Override
		protected void onCancelled()
		{
			super.onCancelled();
			return;
		}

		@Override
		protected void onPostExecute(String result)
		{
			super.onPostExecute(result);
			if ("1".equalsIgnoreCase(result))
			{
				Toast.makeText(SSOActivity.this, "right", Toast.LENGTH_LONG).show();
			} else
			{
				final AlertDialog ad = new AlertDialog(SSOActivity.this)
				{

				};
				Button bt = new Button(SSOActivity.this);
				bt.setText("test");
				bt.setOnClickListener(new OnClickListener()
				{
					@Override
					public void onClick(View arg0)
					{
						ClientVersionUpdataAsyncTask task = new ClientVersionUpdataAsyncTask();
						task.execute(1);
						ad.dismiss();
						ad.cancel();
						return;
					}
				});
				ad.setView(bt);
				ad.show();
			}
			return;
		}

		@Override
		protected void onPreExecute()
		{
			super.onPreExecute();
			return;
		}

		@Override
		protected void onProgressUpdate(Integer... values)
		{
			super.onProgressUpdate(values);
			return;
		}
	}

	@Override
	protected void onResume()
	{
		super.onResume();
		Log.i("test", "Resume");
		return;
	}

	@Override
	protected void onPause()
	{
		super.onPause();
		Log.i("test", "Pause");
		return;
	}
}