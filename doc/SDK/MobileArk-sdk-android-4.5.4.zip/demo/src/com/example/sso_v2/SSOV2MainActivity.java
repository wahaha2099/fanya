package com.example.sso_v2;

import com.fiberhome.arksdkdemo.R;
import com.fiberhome.mobileark.sso_v2.GetParamListener;
import com.fiberhome.mobileark.sso_v2.MobileArkSSOAgent;
import com.fiberhome.mobileark.sso_v2.SSOStatusListener;
import com.fiberhome.mobileark.sso_v2.GetTokenListener;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class SSOV2MainActivity extends Activity {

	private EditText etPackageName;
	private Button btnInit;
	private Button btnGetToken;
	private Button btnGetParam;
	private Button btnGetTokenSync;

	private MobileArkSSOAgent ssoAgent;
	private TextView tvResult;

	private String result;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		initData();
		initHandler();
		initLayout();
		initEvent();
	}

	private void initData() {
		ssoAgent = MobileArkSSOAgent.getInstance(this);
	}

	private void initHandler() {

	}

	private void initEvent() {

		btnInit.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (etPackageName.getText().toString().trim().length() > 0) {
					ssoAgent.setMobilearkPackagename(etPackageName.getText()
							.toString().trim());
				}
				
				ssoAgent.initSSOAgent(new SSOStatusListener() {

					@Override
					public void finishCallBack(int resultCode,
							String resultMessage) {
						Toast.makeText(SSOV2MainActivity.this,
								resultCode + "," + resultMessage,
								Toast.LENGTH_SHORT).show();
					}
				});

			}
		});

		btnGetToken.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				ssoAgent.getToken(new GetTokenListener() {

					@Override
					public void finishCallBack(int resultCode,
							String resultMessage, String token) {
						tvResult.setText("ResultCode:" + resultCode
								+ "; ResultMessage:" + resultMessage
								+ "; Token:" + token);
					}
				});
			}
		});
		
		btnGetTokenSync.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				tvResult.setText(ssoAgent.getToken());
			}
		});
		
		btnGetParam.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				ssoAgent.getParam("loginname", new GetParamListener() {

					@Override
					public void finishCallBack(int resultCode,
							String resultMessage, String value) {
						result = "ResultCode:" + resultCode
								+ "; ResultMessage:" + resultMessage
								+ "; loginname:" + value + ";";
						ssoAgent.getParam("ecid", new GetParamListener() {
							
							@Override
							public void finishCallBack(int resultCode, String resultMessage,
									String value) {
								result += "ResultCode:" + resultCode
										+ "; ResultMessage:" + resultMessage
										+ "; ecid:" + value + ";";
								ssoAgent.getParam("password", new GetParamListener() {
									
									@Override
									public void finishCallBack(int resultCode, String resultMessage,
											String value) {
										result += "ResultCode:" + resultCode
												+ "; ResultMessage:" + resultMessage
												+ "; password:" + value + ";";
										tvResult.setText(result);
									}
								});
							}
						});
					}
				});
			}
		});
	}

	private void initLayout() {
		setContentView(R.layout.activity_ssov2);
		etPackageName = (EditText) findViewById(R.id.et_ssov2_packagename);
		tvResult = (TextView) findViewById(R.id.tv_ssov2_result);
		btnInit = (Button) findViewById(R.id.btn_ssov2_init);
		btnGetToken = (Button) findViewById(R.id.btn_ssov2_check);
		btnGetTokenSync = (Button) findViewById(R.id.btn_ssov2_check_sync);
		btnGetParam = (Button) findViewById(R.id.btn_ssov2_check_param);
	}
}
