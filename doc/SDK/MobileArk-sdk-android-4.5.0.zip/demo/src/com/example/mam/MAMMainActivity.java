package com.example.mam;

import com.fiberhome.arksdkdemo.R;
import com.fiberhome.mobileark.mam.MAMGestureListener;
import com.fiberhome.mobileark.mam.MobileArkMAMAgent;
import com.fiberhome.mobileark.mam.MAMStatusListener;
import com.fiberhome.mobileark.mam.CheckAppVersionListener;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MAMMainActivity extends Activity {

	private TextView tvResult;
	private EditText etAppId;
	private EditText etPackageName;
	private EditText etAppVersion;
	private EditText etAppType;
	private Button btnCheck;
	private Button btnInit;

	private MobileArkMAMAgent agent;

	private CheckAppVersionListener listener;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		initData();
		initLayout();
		initEvent();
	}

	private void initData() {
		// TODO Auto-generated method stub
		listener = new CheckAppVersionListener() {

			@Override
			public void finishCallBack(int code, String resultMessage,
					String upDateFlag, String downloadUrl, String fileSize,
					String updateScription) {
				tvResult.setText("Code:" + code + "; ResultMessage:"
						+ resultMessage + "; UpDateFlag:" + upDateFlag
						+ "; DownloadUrl:" + downloadUrl + "; FileSize:"
						+ fileSize + "; UpdateScription" + updateScription);
			}
		};
		
		agent = MobileArkMAMAgent.getInstance(MAMMainActivity.this);
	}

	private void initEvent() {
		// TODO Auto-generated method stub
		
		btnInit.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				if (etPackageName.getText().toString().trim().length() > 0) {
					agent.setMobilearkPackagename(etPackageName.getText().toString().trim());
				}
				agent.initMAMAgent(new MAMStatusListener() {
					
					@Override
					public void finishCallBack(int resultCode, String resultMessage) {
						// TODO Auto-generated method stub
						Toast.makeText(MAMMainActivity.this, resultCode + "," + resultMessage, Toast.LENGTH_LONG).show();
					}
				});
			}
		});
		
		btnCheck.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {		
				if (etAppId.getText().toString().trim().length() < 0) {
					Toast.makeText(MAMMainActivity.this, "AppId 不能为空",
							Toast.LENGTH_SHORT).show();
					return;
				}

				if (etAppVersion.getText().toString().trim().length() < 0) {
					Toast.makeText(MAMMainActivity.this, "AppVersion 不能为空",
							Toast.LENGTH_SHORT).show();
					return;
				}

				agent.checkAppVersion(etAppId.getText().toString().trim(),
								etAppVersion.getText().toString().trim(), listener);
			}
		});
	}

	private void initLayout() {
		// TODO Auto-generated method stub
		setContentView(R.layout.activity_mam);

		tvResult = (TextView) findViewById(R.id.tv_mam_result);
		etAppId = (EditText) findViewById(R.id.et_mam_appid);
		etPackageName = (EditText) findViewById(R.id.et_mam_packagename);
		etAppVersion = (EditText) findViewById(R.id.et_mam_appversion);
		etAppType = (EditText) findViewById(R.id.et_mam_apptype);
		btnInit = (Button) findViewById(R.id.btn_mam_init);
		btnCheck = (Button) findViewById(R.id.btn_mam_check);
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		agent.onResume(new MAMGestureListener() {
			
			@Override
			public void finishCallBack(int resultCode, String resultMessage) {
				// TODO Auto-generated method stub
				
			}
		});
	}

	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		agent.onPause();
	}

		
	
}
