
package com.example.th3;

import java.text.SimpleDateFormat;
import java.util.Date;

import com.fiberhome.arksdkdemo.R;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;
import android.widget.Toast;

public class MACallbackService extends BroadcastReceiver
{
	public final String PUSHMESSAGE_PARAM = "messagecontent";
	public final String BROADCASE_PUSHMESSAGE = "com.example.th3.MACallbackService";

	@Override
	public void onReceive(Context arg0, Intent arg1)
	{
		if (arg1 != null && arg1.getAction().equals(BROADCASE_PUSHMESSAGE))
		{
			String message = arg1.getStringExtra(PUSHMESSAGE_PARAM);
			showNotification(message, arg0);
			Toast.makeText(arg0, message, Toast.LENGTH_LONG).show();
		}else if(arg1 != null && arg1.getAction().equals(Intent.ACTION_BOOT_COMPLETED)){
			Intent intent = new Intent();
			ComponentName componentName = new ComponentName("com.example", "com.example.th3.MainActivity");
			intent.setComponent(componentName); 
			arg0.startActivity(intent);
		}
		return;
	}

	/**
	 * 在通知栏展示信息
	 * 
	 * @param messageinfo
	 *            展示通知栏中的信息
	 * @param context
	 */
	private void showNotification(String messageinfo, Context context)
	{
		NotificationManager mNotificationManager = (NotificationManager) context
				.getSystemService(Context.NOTIFICATION_SERVICE);
		CharSequence tickerText = messageinfo;

		long when = System.currentTimeMillis();
		Notification notification = new Notification(R.drawable.pushmail_icon, tickerText, when);
		RemoteViews c = new RemoteViews(context.getPackageName(),
				R.layout.pushmail_pushnotification_layout);

		SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
		Date nowdate = new Date(when);
		c.setTextViewText(R.id.notifymessagetitle,
				context.getString(context.getApplicationInfo().labelRes));
		c.setTextViewText(R.id.notifymessagecount, tickerText);
		c.setTextViewText(R.id.notifymessagetime, context.getString(R.string.pushmail_notifytime)
				+ sdf.format(nowdate));
		notification.contentView = c;
		Intent todeleteIntent = new Intent(context.getPackageName() + ".cleannotifymessage");
		PendingIntent deleteIntent = PendingIntent.getBroadcast(context, 0, todeleteIntent, 0);
		notification.deleteIntent = deleteIntent;
		Intent notificationIntent = new Intent(context.getPackageName() + ".openmessage");
		PendingIntent contentIntent = PendingIntent.getBroadcast(context, 0, notificationIntent, 0);
		notification.flags = Intent.FLAG_ACTIVITY_NEW_TASK | Notification.FLAG_AUTO_CANCEL
				| PendingIntent.FLAG_UPDATE_CURRENT;
		notification.contentIntent = contentIntent;
		notification.defaults |= Notification.DEFAULT_SOUND;
		mNotificationManager.notify(R.drawable.pushmail_icon, notification);
		return;
	}
}