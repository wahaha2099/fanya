package com.example.th3;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import android.app.Activity;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

import com.fiberhome.arksdkdemo.R;
import com.fiberhome.mobileark.crpto.api.CryptoInterface;
import com.fiberhome.mobileark.crpto.api.CryptoSDKManager;
import com.fiberhome.mobileark.crpto.api.FileMInterface;
import com.fiberhome.mobileark.crpto.api.InitAuthenticationListener;
import com.fiberhome.mobileark.crpto.api.SetCryptoKeyListener;

public class CryptoTestCaseActivity extends Activity
{
	Button createfolderBtn;
	Button getfolderBtn;
	Button createfileBtn;
	Button delfileBtn;

	Button getkeyBtn;
	
	Button encryfileBtn;
	Button decryfileBtn;
	private Button encryptBtn;
	private Button decryptBtn;
	
	private Button encryptBtn_out;
	private Button decryptBtn_out;

	String path = Environment.getExternalStorageDirectory().getPath();
	String newFilePath = path + "/test.txt";
	
	String string = path + "/demo.txt";

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.crypto_layout);

		try
		{
			copyDemoDataToSD();
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		
		initWorkDir();

		initLayout();

		initListenter();
	}

	private void copyDemoDataToSD() throws IOException 
    {  
        InputStream myInput;  
        OutputStream myOutput = new FileOutputStream(string);  
        myInput = this.getAssets().open("demo.txt");  
        byte[] buffer = new byte[1024];  
        int length = myInput.read(buffer);
        while(length > 0)
        {
            myOutput.write(buffer, 0, length); 
            length = myInput.read(buffer);
        }
        
        myOutput.flush();  
        myInput.close();  
        myOutput.close();        
    }
	
	/**
	 * 设置工作目录
	 */
	private void initWorkDir()
	{
		CryptoSDKManager.getInstance().getFileMInterface(CryptoTestCaseActivity.this)
		.createDirectoryPath("test_createDirectoryPath");
	}
	
	private void initLayout()
	{
		encryptBtn = (Button) findViewById(R.id.encryptBtn);

		decryptBtn = (Button) findViewById(R.id.decryptBtn);
		
		createfolderBtn=(Button) findViewById(R.id.createfolderBtn);
		getfolderBtn=(Button) findViewById(R.id.getfolderBtn);
		createfileBtn=(Button) findViewById(R.id.createfileBtn);
		delfileBtn=(Button) findViewById(R.id.delfileBtn);
		
		getkeyBtn=(Button) findViewById(R.id.getkeyBtn);
		
		encryfileBtn=(Button) findViewById(R.id.encryfileBtn);
		decryfileBtn=(Button) findViewById(R.id.decryfileBtn);
		

		encryptBtn_out=(Button) findViewById(R.id.encryptBtn_out);
		decryptBtn_out=(Button) findViewById(R.id.decryptBtn_out);
	}

	private void initListenter()
	{
		getkeyBtn.setOnClickListener(new OnClickListener()
		{
			
			@Override
			public void onClick(View v)
			{
				CryptoSDKManager.getInstance().getAuthenticationInterfaceV2(getApplicationContext()).initInterface(new InitAuthenticationListener() {
					
					@Override
					public void finishCallBack(int code, String resultMessage) {
						// TODO Auto-generated method stub
						if (code == -1) {
							Toast.makeText(CryptoTestCaseActivity.this, resultMessage, Toast.LENGTH_SHORT).show();
						} else {
							CryptoSDKManager.getInstance().getAuthenticationInterfaceV2(getApplicationContext()).setCryptoKey(new SetCryptoKeyListener() {
								
								@Override
								public void finishCallBack(int code, String resultMessage) {
									// TODO Auto-generated method stub
									if (code == -1) {
										Toast.makeText(CryptoTestCaseActivity.this, resultMessage, Toast.LENGTH_SHORT).show();
									} else {
										Toast.makeText(CryptoTestCaseActivity.this, "设置成功.", Toast.LENGTH_SHORT).show();
									}
								}
							});
						}
					}
				});;
			}
		});
		
		//加密文件
		encryptBtn.setOnClickListener(new OnClickListener()
		{

			@Override
			public void onClick(View arg0)
			{
				FileMInterface fInterface = CryptoSDKManager.getInstance().getFileMInterface(
						CryptoTestCaseActivity.this);
				/**
				 * 第一个参数为：源文件绝对路径 第二个参数为：加密后文件绝对路径
				 */

				boolean isEncryeSuccsss = fInterface.encryFile(string, newFilePath);

				Toast.makeText(CryptoTestCaseActivity.this, "加密完成.", Toast.LENGTH_SHORT).show();

			}
		});

		//解密文件
		decryptBtn.setOnClickListener(new OnClickListener()
		{

			@Override
			public void onClick(View v)
			{
				/**
				 * 第一个参数为：加密文件绝对路径 第二个参数为：解密后文件绝对路径
				 */
				CryptoSDKManager.getInstance().getFileMInterface(CryptoTestCaseActivity.this)
						.decryptFile(newFilePath, path + "/ioswww.txt");

			}
		});
		
		createfolderBtn.setOnClickListener(new OnClickListener()
		{
			
			@Override
			public void onClick(View arg0)
			{
				CryptoSDKManager.getInstance().getFileMInterface(CryptoTestCaseActivity.this)
				.createDirectoryPath("test_createDirectoryPath");
			}
		});
		
		getfolderBtn.setOnClickListener(new OnClickListener()
		{
			
			@Override
			public void onClick(View arg0)
			{
				Toast.makeText(CryptoTestCaseActivity.this, 
						CryptoSDKManager.getInstance().getFileMInterface(CryptoTestCaseActivity.this).getDirectoryPath(), 
						Toast.LENGTH_SHORT).show();
			}
		});
		
		createfileBtn.setOnClickListener(new OnClickListener()
		{
			
			@Override
			public void onClick(View arg0)
			{
				String str="test_createFile.txt";
				CryptoSDKManager.getInstance().getFileMInterface(CryptoTestCaseActivity.this)
				.createFile(str);
				Toast.makeText(CryptoTestCaseActivity.this, "创建文件 "+str+" 成功!", Toast.LENGTH_SHORT).show();
			}
		});
		
		delfileBtn.setOnClickListener(new OnClickListener()
		{
			
			@Override
			public void onClick(View arg0)
			{
				String str="test_createFile.txt";
				CryptoSDKManager.getInstance().getFileMInterface(CryptoTestCaseActivity.this)
				.deleteFileAtPath(str);
				
				Toast.makeText(CryptoTestCaseActivity.this, "删除文件 "+str+" 成功!", Toast.LENGTH_SHORT).show();
			}
		});
		
		encryfileBtn.setOnClickListener(new OnClickListener()
		{
			
			@Override
			public void onClick(View arg0)
			{
				String str="test_encryptDataWriteToFile.txt";
				
				boolean isS = CryptoSDKManager.getInstance().getFileMInterface(CryptoTestCaseActivity.this)
				.encryptDataWriteToFile(str, "加密测试".getBytes());
				if(isS)
				{
					Toast.makeText(CryptoTestCaseActivity.this, "加密数据到文件 "+str+" 成功!", Toast.LENGTH_SHORT).show();
				}
				
			}
		});
		
		decryfileBtn.setOnClickListener(new OnClickListener()
		{
			
			@Override
			public void onClick(View arg0)
			{
				byte[] dataFromEncryptedFile = CryptoSDKManager.getInstance().getFileMInterface(CryptoTestCaseActivity.this)
						.dataFromEncryptedFile("test_encryptDataWriteToFile.txt");
				
				Toast.makeText(CryptoTestCaseActivity.this, "从文件解密内容为："+new String(dataFromEncryptedFile), Toast.LENGTH_SHORT).show();
			}
		});
		
		encryptBtn_out.setOnClickListener(new OnClickListener()
		{
			
			@Override
			public void onClick(View arg0)
			{
				boolean isS = CryptoSDKManager.getInstance()
						.getFileMInterface(CryptoTestCaseActivity.this).encryFile(string);
				if(isS)
				{
					Toast.makeText(CryptoTestCaseActivity.this, "加密文件成功!", Toast.LENGTH_SHORT).show();
				}
				
			}
		});
		
		decryptBtn_out.setOnClickListener(new OnClickListener()
		{
			
			@Override
			public void onClick(View arg0)
			{
				String decryptFile = CryptoSDKManager.getInstance()
				.getFileMInterface(CryptoTestCaseActivity.this).decryptFile(string);
				
				Toast.makeText(CryptoTestCaseActivity.this, "解密文件成功 ->"+decryptFile, Toast.LENGTH_LONG).show();
			}
		});
		
		//copyFile
		findViewById(R.id.decryptSDBtn).setOnClickListener(new OnClickListener()
		{
			
			@Override
			public void onClick(View arg0)
			{
				String copyFile = CryptoSDKManager.getInstance().getFileMInterface(CryptoTestCaseActivity.this)
				.copyFile(string);
				
				Toast.makeText(CryptoTestCaseActivity.this, copyFile, Toast.LENGTH_SHORT).show();
			}
		});
		
		//readFile
		findViewById(R.id.decryptSDBtn2).setOnClickListener(new OnClickListener()
		{
					
			@Override
			public void onClick(View arg0)
			{
				String copyFile = CryptoSDKManager.getInstance().getFileMInterface(CryptoTestCaseActivity.this)
						.copyFile(string);
				
				CryptoSDKManager.getInstance().getFileMInterface(CryptoTestCaseActivity.this)
						.readFile(copyFile);
						
				Toast.makeText(CryptoTestCaseActivity.this, copyFile, Toast.LENGTH_SHORT).show();
			}
		});
	}

}
