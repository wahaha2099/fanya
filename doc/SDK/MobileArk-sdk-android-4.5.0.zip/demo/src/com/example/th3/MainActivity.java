package com.example.th3;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

import com.example.mam.MAMMainActivity;
import com.example.mcm.MCMMainActivity;
import com.example.sso_v2.SSOV2MainActivity;
import com.fiberhome.arksdkdemo.R;

public class MainActivity extends Activity
{
	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
		try {
			
		} catch (Throwable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main_layout); 
		Button sso_btn = (Button)findViewById(R.id.sso_btn);
		Button mcm_btn = (Button) findViewById(R.id.mcm_btn);
		Button mam_btn = (Button) findViewById(R.id.mam_btn);
		Button ssov2_btn = (Button) findViewById(R.id.ssov2_btn);
		Button crypto_btn = (Button)findViewById(R.id.crypto_btn);
		TextView tv = (TextView)findViewById(R.id.version);
		sso_btn.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View arg0) {
				sso_click(arg0);
	
			}
			
		});
		mcm_btn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				mcm_click();
				
			}
			
		});
		mam_btn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				mam_click();
				
			}
			
		});
		ssov2_btn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				ssov2_click();
				
			}
			
		});
		crypto_btn.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View arg0) {
				crypto_click(arg0);
	
			}
			
		});
		
//		  SettingInfo msettingInfo = new SettingInfo();
//        Toast.makeText(getBaseContext(), "自动登录中。。。",Toast.LENGTH_LONG).show();
//        msettingInfo.setIp("192.168.160.98");
//        msettingInfo.setPort("8443");
//        msettingInfo.setOrganization("fiberhome");
//        MAEngineManager.getInstance().init(getBaseContext(), msettingInfo);
//        UserInfo userInfo = new UserInfo();
//        userInfo.setUserName("songyang");
//        userInfo.setPassword("Admin111");
//        userInfo.setClientId("com.fiberhome.mobileark");
//        MAEngineManager.getInstance().login(userInfo, new LoginStatusListener()
//        {
//
//            @Override
//            public void finishCallBack(int arg0,String message)
//            {
//                if (0==arg0)
//                {
//                    Toast.makeText(getBaseContext(), "MDM登陆成功"+message, Toast.LENGTH_LONG).show();
//                    Intent intent = new Intent();
//                    intent.setClass(getBaseContext(),AfterLoginActivity.class);
//                    startActivity(intent);
//                }
//                else
//                {
//                    Toast.makeText(getBaseContext(), "MDM登陆失败"+message, Toast.LENGTH_LONG).show();
//                }
//
//            }
//
//        });
    }
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		// TODO Auto-generated method stub
		Log.i("onKeyDown", "keyid:" + keyCode + "keyevent:" + event);
		return super.onKeyDown(keyCode, event);
	}
	public void sso_click(View v) 
	{
		Intent it=new Intent(this,SSOActivity.class);
		startActivity(it);
	}
	
	public void crypto_click(View v) 
	{
		Intent it=new Intent(this,CryptoTestCaseActivity.class);
		startActivity(it);
	}
	
	private void mcm_click() {
		// TODO Auto-generated method stub
		Intent it=new Intent(this,MCMMainActivity.class);
		startActivity(it);
	}
	
	private void mam_click() {
		// TODO Auto-generated method stub
		Intent it=new Intent(this,MAMMainActivity.class);
		startActivity(it);
	}
	
	private void ssov2_click() {
		// TODO Auto-generated method stub
		Intent it=new Intent(this,SSOV2MainActivity.class);
		startActivity(it);
	}
}
