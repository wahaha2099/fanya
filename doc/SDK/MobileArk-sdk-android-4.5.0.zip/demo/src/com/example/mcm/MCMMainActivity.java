package com.example.mcm;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import com.fiberhome.arksdkdemo.R;
import com.fiberhome.mobiark.mcm.DocDownloadUrlOrPreviewUrlListener;
import com.fiberhome.mobiark.mcm.DocumentInfo;
import com.fiberhome.mobiark.mcm.FileUploadListener;
import com.fiberhome.mobiark.mcm.FolderInfo;
import com.fiberhome.mobiark.mcm.MobileArkMCMAgent;
import com.fiberhome.mobiark.mcm.PersonDocumentListListener;
import com.fiberhome.mobiark.mcm.PersonInfo;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MCMMainActivity extends Activity {
	
	private MobileArkMCMAgent agent;
	private PersonInfo settings;
	
	private Button btSet;
	private Button btGetList;
	private Button btGetUrlDown;
	private Button btGetUrlPre;
	private Button btUpload;
	private EditText etIp;
	private EditText etPort;
	private EditText etEcid;
	private EditText etUsername;
	private EditText etPassword;
	private EditText etGetUrl;
	private EditText etUploadFolder;
	private EditText etUploadDoc;
	
	private ArrayList<DocumentInfo> mDocumentList = new ArrayList<DocumentInfo>();
	private ArrayList<FolderInfo> mFolderList = new ArrayList<FolderInfo>();
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		
		initData();
		initLayout();
		initEvent();
	}

	private void initEvent() {
		// TODO Auto-generated method stub
		
		btSet.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if (etEcid.getText() == null 
					|| etIp.getText() == null	 
					|| etUsername.getText() == null 
					|| etPassword.getText() == null 
					|| etPort.getText() == null) {
					Toast.makeText(getApplicationContext()
							, "输入为空"
							, Toast.LENGTH_SHORT).show();
					return;
				}
				
				settings = new PersonInfo();
				settings.setEcid(etEcid.getText().toString());
				settings.setIp(etIp.getText().toString());
				settings.setLoginid(etUsername.getText().toString());
				settings.setPassword(etPassword.getText().toString());
				settings.setPort(etPort.getText().toString());
				agent = new MobileArkMCMAgent(getApplicationContext());
				
				Toast.makeText(getApplicationContext()
						, "应用完成"
						, Toast.LENGTH_SHORT).show();
			}
		});
		
		btGetList.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				agent.getPersonDocumentList(getApplicationContext(), settings, "-1", 0, new PersonDocumentListListener() {

					@Override
					public void finishCallBack(int code, String message,
							ArrayList<DocumentInfo> documentlist,
							ArrayList<FolderInfo> folderList) {
						// TODO Auto-generated method stub
						    mDocumentList = documentlist;
						    mFolderList = folderList;
							if(0 == code) {
								Toast.makeText(getApplicationContext()
										, "个人文件夹根目录下共有" + folderList.size() + "个文件夹，和" + documentlist.size() + "个文件。"
										, Toast.LENGTH_LONG).show();
							} else {
								Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
							}
						
						}
						
				});
			}
		});
		
		btGetUrlDown.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(mDocumentList.size() > 0) {
					if (etGetUrl.getText() == null) {
						
						Toast.makeText(getApplicationContext(), "输入文件序号", Toast.LENGTH_SHORT).show();
						return;
					}
					if (1 > Integer.valueOf(etGetUrl.getText().toString()) 
							|| Integer.valueOf(etGetUrl.getText().toString()) > mDocumentList.size()) {
						
						Toast.makeText(getApplicationContext(), "输入值超出范围", Toast.LENGTH_SHORT).show();
						return;
					}
					
					
					if (mDocumentList.get(Integer.valueOf(etGetUrl.getText().toString()) - 1).isPreviewPermit()) {
						Toast.makeText(getApplicationContext(), "获取下载地址", Toast.LENGTH_SHORT).show();
						agent.getDocDownloadUrlOrPreviewUrl(getApplicationContext(), settings, mDocumentList.get(Integer.valueOf(etGetUrl.getText().toString()) - 1).getDocumentid()
								, "1"
								, new DocDownloadUrlOrPreviewUrlListener() {

							@Override
							public void finishCallBack(int code,
									String message, String documenturl,
									List<String> previewurlList) {
								// TODO Auto-generated method stub
								if(0 == code) {
									Toast.makeText(getApplicationContext()
											, documenturl
											, Toast.LENGTH_SHORT).show();
								} else {
									Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
								}
							}
						});
					} else {
						Toast.makeText(getApplicationContext(), "文件不允许下载", Toast.LENGTH_SHORT).show();
					}				
				}
			}
		});
		
		btGetUrlPre.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(mDocumentList.size() > 0) {
					if (etGetUrl.getText() == null) {
						
						Toast.makeText(getApplicationContext(), "输入文件序号", Toast.LENGTH_SHORT).show();
						return;
					}
					if (1 > Integer.valueOf(etGetUrl.getText().toString()) 
							|| Integer.valueOf(etGetUrl.getText().toString()) > mDocumentList.size()) {
						
						Toast.makeText(getApplicationContext(), "输入值超出范围", Toast.LENGTH_SHORT).show();
						return;
					}
					
					
					if(mDocumentList.get(Integer.valueOf(etGetUrl.getText().toString()) - 1).isPermitDownload()) {
						Toast.makeText(getApplicationContext(), "获取预览地址", Toast.LENGTH_SHORT).show();
						agent.getDocDownloadUrlOrPreviewUrl(getApplicationContext(), settings, mDocumentList.get(Integer.valueOf(etGetUrl.getText().toString()) - 1).getDocumentid(), "2"
								, new DocDownloadUrlOrPreviewUrlListener() {

							@Override
							public void finishCallBack(int code,
									String message, String documenturl,
									List<String> previewurlList) {
								// TODO Auto-generated method stub
								if(0 == code) {
									Toast.makeText(getApplicationContext()
											, previewurlList.get(0)
											, Toast.LENGTH_SHORT).show();
								} else {
									Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
								}			
							}
							
						});
					} else {
						Toast.makeText(getApplicationContext(), "文件不允许预览", Toast.LENGTH_SHORT).show();
					}
				}
			}
		});
		
		btUpload.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(mFolderList.size() > 0) {
					
					if (etUploadDoc.getText() == null || etUploadFolder.getText() == null) {
						
						Toast.makeText(getApplicationContext(), "输入为空", Toast.LENGTH_SHORT).show();
						return;
					}
					if (0 > Integer.valueOf(etUploadFolder.getText().toString()) 
							|| Integer.valueOf(etUploadFolder.getText().toString()) > mFolderList.size()) {
						
						Toast.makeText(getApplicationContext(), "输入值超出范围", Toast.LENGTH_SHORT).show();
						return;
					}
			       
					File file = new File(etUploadDoc.getText().toString());
					if(file.exists()) {
						agent.fileUpload(getApplicationContext(), settings, etUploadDoc.getText().toString()
								, etUploadFolder.getText().toString().equals("0")?
										"-1" : mFolderList.get(Integer.valueOf(etUploadFolder.getText().toString()) - 1).getFolderid(), new FileUploadListener() {
									
									@Override
									public void finishCallBack(int code, String message, int progress) {
										// TODO Auto-generated method stub
										Toast.makeText(getApplicationContext()
												, code + ":" + message + ". progress:" + progress
												, Toast.LENGTH_LONG).show();
									}
								});
					} else {
						Toast.makeText(getApplicationContext()
								, "文件不存在"
								, Toast.LENGTH_SHORT).show();
					}
				}			
			}
		});
	}

	private void initLayout() {
		// TODO Auto-generated method stub
		setContentView(R.layout.activity_mcm);
		btSet = (Button) findViewById(R.id.mcm_set);
		btGetList = (Button) findViewById(R.id.mcm_get_list);
		btGetUrlDown = (Button) findViewById(R.id.mcm_get_url_dow);
		btGetUrlPre = (Button) findViewById(R.id.mcm_get_url_pre);
		btUpload = (Button) findViewById(R.id.mcm_upload);
		etIp = (EditText) findViewById(R.id.et_ip);
		etPort = (EditText) findViewById(R.id.et_port);
		etEcid = (EditText) findViewById(R.id.et_ecid);
		etUsername = (EditText) findViewById(R.id.et_username);
		etPassword = (EditText) findViewById(R.id.et_password);
		etGetUrl = (EditText) findViewById(R.id.et_geturl);
		etUploadFolder = (EditText) findViewById(R.id.et_upload_folder);
		etUploadDoc = (EditText) findViewById(R.id.et_upload_doc);
	}

	private void initData() {
		// TODO Auto-generated method stub
	}
}
